# Source Generated with Decompyle++
# File: main.pyc (Python 3.12)

'''
BioLock SSD  v9.0  Final
'''
import os
import sys
import time
import json
import pickle
import hashlib
import secrets
import base64
import datetime
import threading
import subprocess
import shutil
import ctypes
import string
import math
import tkinter as tk
from tkinter import ttk, messagebox
import cv2
import numpy as np
from PIL import Image, ImageTk
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

try:
    import winreg
    _WIN = True
    APP_VERSION = '9.0'
    ENROL_FRAMES = 100
    MIN_CONF = 40
    MAX_ATTEMPTS = 5
    BLINKS_NEEDED = 2
    HEAD_TURN_PCT = 10
    MOTION_THRESH = 0.03
    MOTION_FRAMES = 20
    BLINK_MIN_CL = 2
    PROCESS_EVERY = 2
    AUTO_LOCK_M = 5
    WATCHER_KEY = 'BioLockUSB'
    BG = '#060612'
    SURFACE = '#0c0c20'
    CARD = '#10102a'
    BORDER = '#1e1e48'
    ACCENT = '#6d28d9'
    ACCENT_L = '#8b5cf6'
    TEAL = '#0891b2'
    TEAL_L = '#22d3ee'
    GREEN = '#059669'
    GREEN_L = '#34d399'
    RED = '#dc2626'
    RED_L = '#f87171'
    AMBER = '#d97706'
    AMBER_L = '#fbbf24'
    FG = '#f5f5ff'
    MUTED = '#9494b8'
    FAINT = '#1f1f48'
    CAM_NAMES = {
        0: 'Built-in webcam',
        1: 'External / phone',
        2: 'Virtual camera' }
    
    def _base():
        if getattr(sys, 'frozen', False):
            return os.path.dirname(sys.executable)
        return None(os.path.dirname.path.abspath(__file__))

    
    def _p(*x):
        pass
    # WARNING: Decompyle incomplete

    LOCK_DIR = _p('.biolock')
    MODEL_FILE = _p('.biolock', 'face.xml')
    STATS_FILE = _p('.biolock', 'face_stats.pkl')
    VAULT_KEY = _p('.biolock', 'vault.key')
    STATE_FILE = _p('.biolock', 'state.json')
    LOG_FILE = _p('.biolock', 'audit.log')
    CFG_FILE = _p('.biolock', 'config.json')
    SNAP_DIR = _p('.biolock', 'snapshots')
    VAULT_DIR = _p('SecureVault')
    DRIVE_ID = _p('.biolock', 'drive.id')
    NW = 134217728
    
    def _hide(p):
        if p:
            if os.path.exists(p):
                
                try:
                    subprocess.run([
                        'attrib',
                        '+h',
                        '+s',
                        p], capture_output = True, creationflags = NW)
                    return None
                    return None
                    return None
                except:
                    return None


    
    def _unhide(p):
        if p:
            if os.path.exists(p):
                
                try:
                    subprocess.run([
                        'attrib',
                        '-h',
                        '-s',
                        p], capture_output = True, creationflags = NW)
                    return None
                    return None
                    return None
                except:
                    return None


    
    def _log(ev, detail, level = ('', 'INFO')):
        
        try:
            os.makedirs(LOCK_DIR, exist_ok = True)
            _unhide(LOG_FILE)
            ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            line = f'''[{ts}] [{level}] {ev}'''
            if detail:
                line += f'''  |  {detail}'''
            f = open(LOG_FILE, 'a', encoding = 'utf-8')
            f.write(line + '\n')
            
            try:
                None(None, None)
                _hide(LOG_FILE)
                return None
                with None:
                    if not None:
                        pass
                
                try:
                    continue
                except:
                    return None




    
    def _beep(f, d = (880, 120)):
        
        try:
            if _WIN:
                ctypes.windll.kernel32.Beep(f, d)
                return None
            return None
        except:
            return None


    
    def _sound_ok():
        threading.Thread(target = (lambda : [
_beep(880, 80),
time.sleep(0.05),
_beep(1108, 80),
time.sleep(0.05),
_beep(1318, 150)]), daemon = True).start()

    
    def _sound_fail():
        threading.Thread(target = (lambda : [
_beep(400, 200),
time.sleep(0.05),
_beep(300, 300)]), daemon = True).start()

    
    def _sound_blink():
        threading.Thread(target = (lambda : _beep(1200, 40)), daemon = True).start()

    
    def _drive_letter():
        
        try:
            drive = os.path.splitdrive(_base())[0]
            if not drive.rstrip(':\\').upper():
                drive.rstrip(':\\').upper()
            return '?'
        except:
            return '?'


    
    def _is_removable(letter):
        
        try:
            return ctypes.windll.kernel32.GetDriveTypeW(f'''{letter}:\\''') == 2
        except:
            return True


    
    def _drive_free_gb(letter):
        
        try:
            import shutil
            st = shutil.disk_usage(f'''{letter}:\\''')
            return (st.free / 1073741824, st.total / 1073741824)
        except:
            return (0, 0)


    
    def _vault_size_mb():
        
        try:
            total = (lambda .0: pass# WARNING: Decompyle incomplete
)(os.walk(VAULT_DIR)())
            return total / 1048576
        except:
            return 0


    
    def _create_drive_id():
        os.makedirs(LOCK_DIR, exist_ok = True)
        uid = secrets.token_hex(16)
        _unhide(DRIVE_ID)
        f = open(DRIVE_ID, 'w')
        json.dump({
            'id': uid,
            'created': datetime.datetime.now().isoformat(),
            'version': APP_VERSION }, f)
        None(None, None)
        _hide(DRIVE_ID)
        return uid
        with None:
            if not None:
                pass
        continue

    
    def _get_drive_id():
        if not os.path.exists(DRIVE_ID):
            return None
    # WARNING: Decompyle incomplete

    
    def _write_autorun():
        
        try:
            inf = _p('autorun.inf')
            _unhide(inf)
            f = open(inf, 'w')
            f.write('[autorun]\nopen=BioLock.exe\nicon=BioLock.exe,0\nlabel=BioLock Secure Drive\naction=Unlock with BioLock\n')
            
            try:
                None(None, None)
                return None
                with None:
                    if not None:
                        pass
                
                try:
                    return None
                    
                    try:
                        pass
                    except:
                        return None





    
    def _register_autorun():
        if not _WIN:
            return None
        
        try:
            exe = sys.executable if getattr(sys, 'frozen', False) else os.path.abspath(__file__)
            k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, 'Software\\Microsoft\\Windows\\CurrentVersion\\Run', 0, winreg.KEY_SET_VALUE)
            winreg.SetValueEx(k, WATCHER_KEY, 0, winreg.REG_SZ, f'''"{exe}"''')
            
            try:
                None(None, None)
                return None
                with None:
                    if not None:
                        pass
                
                try:
                    return None
                    
                    try:
                        pass
                    except:
                        return None





    DEF_STATE = {
        'enrolled': False,
        'attempts': 0,
        'total_unlocks': 0,
        'last_unlock': None,
        'enrol_quality': 0 }
    DEF_CFG = {
        'auto_lock_mins': AUTO_LOCK_M,
        'cam_index': None }
    
    def _load_state():
        pass
    # WARNING: Decompyle incomplete

    
    def _save_state(s):
        os.makedirs(LOCK_DIR, exist_ok = True)
        _unhide(STATE_FILE)
        f = open(STATE_FILE, 'w')
        json.dump(s, f)
        None(None, None)
        _hide(STATE_FILE)
        _hide(LOCK_DIR)
        return None
        with None:
            if not None:
                pass
        continue

    
    def _load_cfg():
        pass
    # WARNING: Decompyle incomplete

    
    def _save_cfg(c):
        os.makedirs(LOCK_DIR, exist_ok = True)
        _unhide(CFG_FILE)
        f = open(CFG_FILE, 'w')
        json.dump(c, f)
        None(None, None)
        _hide(CFG_FILE)
        return None
        with None:
            if not None:
                pass
        continue

    
    def _fernet(fh, salt):
        kdf = PBKDF2HMAC(algorithm = hashes.SHA256(), length = 32, salt = salt, iterations = 600000)
        return Fernet(base64.urlsafe_b64encode(kdf.derive(fh)))

    
    def save_vault_key(fh):
        salt = secrets.token_bytes(16)
        token = _fernet(fh, salt).encrypt(b'BIOLOCK_VAULT_OK')
        os.makedirs(LOCK_DIR, exist_ok = True)
        _unhide(VAULT_KEY)
        f = open(VAULT_KEY, 'wb')
        f.write(salt + token)
        None(None, None)
        _hide(VAULT_KEY)
        return None
        with None:
            if not None:
                pass
        continue

    
    def verify_vault_key(fh):
        if not os.path.exists(VAULT_KEY):
            return False
    # WARNING: Decompyle incomplete

    
    def _find_cc(name):
        cands = []
        
        try:
            cands.append(cv2.data.haarcascades + name)
            d = os.path.dirname(cv2.__file__)
            for sub in ('data', os.path.join('..', 'data'), ''):
                cands.append(os.path.normpath(os.path.join(d, sub, name)))
            for p in cands:
                if not os.path.isfile(p):
                    continue
                
                return cands, p
            return None
        except:
            continue


    FACE_XML = _find_cc('haarcascade_frontalface_default.xml')
    EYE_XML = _find_cc('haarcascade_eye.xml')
    
    def _pre(img):
        return cv2.resize(cv2.GaussianBlur(cv2.equalizeHist(img), (3, 3), 0), (100, 100))

    
    def _lighting_quality(face_gray):
        mean = float(np.mean(face_gray))
        std = float(np.std(face_gray))
        score = 100
        msg = 'Lighting OK'
        if mean < 60:
            score -= 40
            msg = 'Too dark — face a light source'
        if mean > 210:
            score -= 40
            msg = 'Too bright — reduce direct light'
        if std < 20:
            score -= 30
            msg = 'Flat lighting — try side light'
        return (max(0, score), msg)

    
    class BlinkDetector:
        
        def __init__(self):
            self.eye_cc = cv2.CascadeClassifier(EYE_XML) if EYE_XML else None
            self.blinks = 0
            self.closed = 0
            self.prev_mean = None
            self.is_done = False
            self._cool = 0

        
        def reset(self):
            self.__init__()

        
        def update(self, face_gray):
            if self.is_done:
                return (self.blinks, True, f'''✓  {BLINKS_NEEDED} blinks confirmed''')
            self._cool = None(0, self._cool - 1)
            eyes_open = True
            if not self.eye_cc and self.eye_cc.empty():
                eyes = self.eye_cc.detectMultiScale(face_gray, 1.08, 3, minSize = (15, 15))
                eyes_open = len(eyes) >= 1
            if not eyes_open:
                pass
            elif self.closed >= BLINK_MIN_CL and self._cool == 0:
                8 = self, self.blinks += 1, .blinks
                _sound_blink()
            self.closed = 0
            h = face_gray.shape[0]
            band = face_gray[(int(h * 0.15):int(h * 0.5), :)]
            cur = float(np.mean(band))
        # WARNING: Decompyle incomplete


    
    class HeadTurn:
        L = 'left'
        R = 'right'
        D = 'done'
        
        def __init__(self):
            self.phase = self.L
            self.baseline = None
            self._buf = []
            self.is_done = False

        
        def reset(self):
            self.__init__()

        
        def update(self, box):
            if self.is_done:
                return (self.D, True, 'PASS Head movement', 'Head turn done')
        # WARNING: Decompyle incomplete


    
    class MotionLive:
        
        def __init__(self):
            self._prev = None
            self._m = []
            self.is_live = False
            self._score = 0

        
        def reset(self):
            self.__init__()

        
        def update(self, gray, box):
            if self.is_live:
                return (True, 1, 'PASS Liveness', self._score)
        # WARNING: Decompyle incomplete


    
    class FaceEngine:
        
        def __init__(self):
            if not FACE_XML:
                raise RuntimeError('Cascade not found.\npip install opencv-contrib-python==4.10.0.84')
            self.cc = cv2.CascadeClassifier(FACE_XML)
            self.lbph = cv2.face.LBPHFaceRecognizer_create(radius = 1, neighbors = 8, grid_x = 8, grid_y = 8)
            self.mean_face = None
            self.ref_hists = []
            self._mff = None
            self._fhc = None
            self.trained = self._load()

        
        def _load(self):
            pass
        # WARNING: Decompyle incomplete

        
        def detect_all(self, gray):
            f = self.cc.detectMultiScale(gray, 1.05, 5, minSize = (60, 60), flags = cv2.CASCADE_SCALE_IMAGE)
            if len(f):
                return list(f)

        
        def detect(self, gray):
            f = self.detect_all(gray)
            if len(f) != 1:
                return None
            return None[0]

        
        def roi(self, gray, box):
            (x, y, w, h) = box
            return _pre(gray[(y:y + h, x:x + w)])

        
        def raw_roi(self, gray, box):
            (x, y, w, h) = box
            return gray[(y:y + h, x:x + w)]

        
        def train(self, samples):
            samples = samples[:ENROL_FRAMES]
            arr = np.array(samples, dtype = np.uint8)
            lbl = np.zeros(len(samples), dtype = np.int32)
            self.lbph.train(arr, lbl)
            self.mean_face = np.mean(arr, axis = 0).astype(np.uint8)
            self._mff = self.mean_face.astype(np.float32)
            orig = samples[0]
        # WARNING: Decompyle incomplete

        
        def predict(self, roi):
            pass
        # WARNING: Decompyle incomplete

        
        def wipe(self):
            self.trained = False
            self.mean_face = None
            self.ref_hists = []
            self._mff = None
            self._fhc = None
            for n in ('face.xml', 'face_stats.pkl', 'vault.key', 'state.json', 'audit.log', 'config.json', 'drive.id'):
                p = _p('.biolock', n)
                _unhide(p)
                if not os.path.exists(p):
                    continue
                os.remove(p)
            if os.path.exists(SNAP_DIR):
                
                try:
                    shutil.rmtree(SNAP_DIR)
                    return None
                    return None
                    continue
                except:
                    return None



    
    class ParticleSystem:
        
        def __init__(self):
            self.active = False
            self.W = 0
            self.H = 0
            self.px = None
            self.py = None

        
        def burst(self, cx, cy, W, H, n = (140,)):
            self.W = W
            self.H = H
            self.active = True
            ang = np.random.uniform(0, math.pi * 2, n)
            spd = np.random.uniform(2, 9, n)
            self.px = np.full(n, float(cx))
            self.py = np.full(n, float(cy))
            self.vx = np.cos(ang) * spd
            self.vy = np.sin(ang) * spd
            self.life = np.ones(n)
            self.decay = np.random.uniform(0.018, 0.045, n)
            self.sizes = np.random.randint(3, 10, n)
            pal = np.array([
                (34, 197, 94),
                (139, 92, 246),
                (34, 211, 238),
                (251, 191, 36),
                (240, 240, 255)], dtype = np.uint8)
            self.cols = pal[np.random.randint(0, len(pal), n)]

        
        def update(self, frame):
            pass
        # WARNING: Decompyle incomplete


    
    class Anim:
        
        def __init__(self):
            self._t = time.time()
            self._scan = 0
            self._pulse = 0
            self._pd = 1
            self._flash = 0
            self.particles = ParticleSystem()

        
        def tick(self):
            dt = time.time() - self._t
            self._t = time.time()
            self._scan = (self._scan + int(240 * dt)) % 720
            if self._pulse >= 1:
                1 = self, self._pulse += self._pd * dt * 2, ._pulse
                self._pd = -1
            elif self._pulse <= 0:
                self._pulse = 0
                self._pd = 1
            self._flash = max(0, self._flash - dt * 2.5)

        
        def flash_green(self):
            self._flash = 1

        
        def _bgr(self, h):
            h = h.lstrip('#')
            return (int(h[4:6], 16), int(h[2:4], 16), int(h[0:2], 16))

        
        def render(self, frame, all_boxes, box, stage, conf, steps, instr, label, col_hex, multi, quality = (False, 100)):
            pass
        # WARNING: Decompyle incomplete


    
    def _scan_cams():
        found = []
    # WARNING: Decompyle incomplete

    
    class CamPicker(tk.Toplevel):
        pass
    # WARNING: Decompyle incomplete

    
    class Splash:
        
        def __init__(self, root):
            self.root = root
            self.win = tk.Toplevel(root)
            self.win.overrideredirect(True)
            self.win.configure(bg = BG)
            sw = root.winfo_screenwidth()
            sh = root.winfo_screenheight()
            (W, H) = (560, 360)
            self.win.geometry(f'''{W}x{H}+{(sw - W) // 2}+{(sh - H) // 2}''')
            self.win.attributes('-topmost', True)
            fr = tk.Frame(self.win, bg = ACCENT, padx = 2, pady = 2)
            fr.pack(fill = 'both', expand = True)
            inn = tk.Frame(fr, bg = BG)
            inn.pack(fill = 'both', expand = True)
            tk.Label(inn, text = '🔒', font = ('Segoe UI', 58), fg = ACCENT_L, bg = BG).pack(pady = (34, 4))
            tk.Label(inn, text = 'BioLock SSD', font = ('Segoe UI', 26, 'bold'), fg = FG, bg = BG).pack()
            tk.Label(inn, text = f'''Version {APP_VERSION}  ·  Final Year Project''', font = ('Segoe UI', 11), fg = MUTED, bg = BG).pack(pady = (2, 16))
            self.bar_v = tk.DoubleVar(value = 0)
            sty = ttk.Style()
            sty.theme_use('default')
            sty.configure('SP.Horizontal.TProgressbar', troughcolor = FAINT, background = ACCENT_L, thickness = 5, borderwidth = 0)
            ttk.Progressbar(inn, style = 'SP.Horizontal.TProgressbar', variable = self.bar_v, mode = 'determinate', length = 400).pack()
            self.msg = tk.Label(inn, text = 'Initialising…', font = ('Segoe UI', 10), fg = MUTED, bg = BG)
            self.msg.pack(pady = 8)
            tk.Label(inn, text = 'CMR Technical Campus  ·  CSE-E  ·  R-22  ·  Rishi · Karthik · Tejasree', font = ('Segoe UI', 8), fg = FAINT, bg = BG).pack()
            self.win.update()

        
        def update(self, pct, msg):
            
            try:
                self.bar_v.set(pct)
                self.msg.config(text = msg)
                self.win.update()
                return None
            except:
                return None


        
        def close(self):
            
            try:
                self.win.destroy()
                return None
            except:
                return None



    
    def show_about(root):
        pass
    # WARNING: Decompyle incomplete

    
    class BioLock:
        ST_MOTION = 0
        ST_BLINK = 1
        ST_HEAD = 2
        ST_FACE = 3
        MODE_IDLE = 'idle'
        MODE_ENROL = 'enrol'
        MODE_VERIFY = 'verify'
        
        def __init__(self, root):
            pass
        # WARNING: Decompyle incomplete

        
        def _fs(self):
            self._fsv = not (self._fsv)
            self.root.attributes('-fullscreen', self._fsv)

        
        def _esc(self):
            if self._fsv:
                self._fsv = False
                self.root.attributes('-fullscreen', False)
                return None
            if self.mode != self.MODE_IDLE:
                self._stop(reset = True)
                return None

        
        def _session_check(self):
            
            try:
                if self.unlocked:
                    idle = time.time() - self._last_act
                    mins = self.cfg.get('auto_lock_mins', AUTO_LOCK_M)
                    rem = int(mins * 60 - idle)
                    if rem <= 0:
                        self._lock()
                        _log('AUTO-LOCK', f'''idle {mins}min''')
                    elif rem <= 60:
                        self.timer_lbl.config(text = f'''⏱  Auto-lock {rem}s''', fg = AMBER_L)
                    else:
                        self.timer_lbl.config(text = f'''⏱  Auto-lock {rem // 60}m''', fg = FAINT)
                else:
                    self.timer_lbl.config(text = '')
                self.root.after(5000, self._session_check)
                return None
            except:
                continue


        
        def _update_drive_bar(self):
            
            try:
                (free, total) = _drive_free_gb(self.drive_ltr)
                vmb = _vault_size_mb()
                used = max(0, min(100, int((1 - free / max(total, 0.001)) * 100)))
                self.drive_info.config(text = f'''{self.drive_ltr}:  {free:.1f} GB free  ·  Vault {vmb:.1f} MB''')
                self.drive_bar['value'] = used
                self.root.after(30000, self._update_drive_bar)
                return None
            except:
                continue


        
        def _build_ui(self):
            pass
        # WARNING: Decompyle incomplete

        
        def _grad(self, c):
            
            try:
                w = c.winfo_width()
                if w < 10:
                    return None
                    
                    try:
                        for i in range(w):
                            t = i / w
                            r = int(109 + -101 * t)
                            g = int(40 + 105 * t)
                            b = int(217 + -39 * t)
                            c.create_line(i, 0, i, 3, fill = f'''#{r:02x}{g:02x}{b:02x}''')
                        return None
                    except:
                        return None



        
        def _show_ph(self, t):
            self.vid.place_forget()
            self.ph.config(text = t)
            self.ph.place(relx = 0.5, rely = 0.5, anchor = 'center')

        
        def _show_vid(self):
            self.ph.place_forget()
            self.vid.place(relx = 0.5, rely = 0.5, anchor = 'center')

        
        def _pset(self, v):
            self.pbar['value'] = v
            
            try:
                self.pbar_pct.config(text = f'''{int(v)}%''')
                return None
            except:
                return None


        
        def _upd_steps(self, stage):
            for ic, lb in enumerate(self.step_labels):
                s = i + 1
                if stage > s:
                    ic.config(text = 'OK', fg = GREEN_L)
                    lb.config(fg = GREEN_L)
                    continue
                if stage == s:
                    ic.config(text = '>>', fg = ACCENT_L)
                    lb.config(fg = FG)
                    continue
                ic.config(text = 'o', fg = FAINT)
                lb.config(fg = MUTED)

        
        def _steps(self, s1, s2, s3, s4, a):
            return [
                ('Presence', s1, a == 1),
                (f'''Blink ×{BLINKS_NEEDED}''', s2, a == 2),
                ('Head L→R', s3, a == 3),
                ('Face match', s4, a == 4)]

        
        def _refresh(self):
            for b in (self.b_main, self.b_lock, self.b_cam, self.b_log, self.b_wipe):
                b.pack_forget()
            atts = self.state.get('attempts', 0)
            self.mv_att.set(f'''{atts}/{MAX_ATTEMPTS}''')
            if self.att_lbl:
                if atts >= 3:
                    pass
                elif atts > 0:
                    pass
                
                AMBER_L(fg = ACCENT_L)
            total = self.state.get('total_unlocks', 0)
            if self.unlocked:
                self.hl.config(text = 'Vault\nOpen')
                self.rule.config(bg = GREEN)
                self.sl.config(text = f'''Session active  ·  {total} total unlock(s)''')
                self.sv.set('Vault is open and accessible.')
                self._upd_steps(5)
                self.b_main.config(text = 'Open  SecureVault', bg = GREEN, fg = '#000')
                self.b_main.pack(fill = 'x', pady = 4)
                self.b_lock.pack(fill = 'x', pady = 4)
                self.b_log.pack(fill = 'x', pady = 4)
                self._show_ph('Vault unlocked  ✓\n\nClick  Open SecureVault  to see your files.\nClick  Lock vault  when finished.\n\nAuto-locks after idle.')
                return None
            if not self.state.get('enrolled'):
                self.hl.config(text = 'Welcome\nto BioLock')
                self.rule.config(bg = AMBER)
                self.sl.config(text = f'''Drive {self.drive_ltr}:  ready  ·  Enrol your face once to secure this drive.''')
                self.sv.set('First time setup — click  Begin face enrolment.')
                self._upd_steps(0)
                self.b_main.config(text = 'Begin face enrolment', bg = ACCENT, fg = '#fff')
                self.b_main.pack(fill = 'x', pady = 4)
                self.b_cam.pack(fill = 'x', pady = 4)
                self._show_ph(f'''BioLock is installed on drive  {self.drive_ltr}:\n\nOne-time face enrolment:\n\n  1.  Click  Begin face enrolment\n  2.  Select your camera when asked\n  3.  Stay still — presence detected\n  4.  Blink  {BLINKS_NEEDED}  times\n  5.  Turn head slowly LEFT then RIGHT\n  6.  Hold still — 100 frames captured\n\nAfter enrolment:\n  •  Your face is the ONLY key to this drive\n  •  {MAX_ATTEMPTS} failed attempts = automatic wipe\n  •  Auto-locks after {AUTO_LOCK_M} min idle''')
                return None
            rem = MAX_ATTEMPTS - atts
            self.hl.config(text = 'Drive\nLocked')
            self.rule.config(bg = RED)
            self.sl.config(text = f'''4-step verification required  ·  {rem} attempt(s) remaining''')
            self.sv.set('Click  Unlock with face ID')
            self._upd_steps(0)
            self.b_main.config(text = 'Unlock with face ID', bg = ACCENT, fg = '#fff')
            self.b_main.pack(fill = 'x', pady = 4)
            self.b_cam.pack(fill = 'x', pady = 4)
            self.b_log.pack(fill = 'x', pady = 4)
            self.b_wipe.pack(fill = 'x', pady = (14, 4))
            self._show_ph(f'''Drive is locked.\n\nClick  Unlock with face ID  — camera opens here.\n\n4-step verification:\n  1.  Presence detected  (stay still)\n  2.  Blink  {BLINKS_NEEDED}  times\n  3.  Turn head left → right\n  4.  Face matched at  {MIN_CONF:.0f}%+  confidence\n\n⚠  Only the enrolled face can pass.\n    {rem} attempt(s) before automatic wipe.''')

        
        def _primary(self):
            self._last_act = time.time()
            if self.unlocked:
                os.makedirs(VAULT_DIR, exist_ok = True)
                _unhide(VAULT_DIR)
                subprocess.Popen(f'''explorer "{VAULT_DIR}"''')
                return None
            if not self.state.get('enrolled'):
                self._start(self.MODE_ENROL)
                return None
            None(self.MODE_VERIFY)

        
        def _pick_cam(self):
            d = CamPicker(self.root)
            self.root.wait_window(d)
        # WARNING: Decompyle incomplete

        
        def _start(self, mode):
            d = CamPicker(self.root)
            self.root.wait_window(d)
        # WARNING: Decompyle incomplete

        
        def _open_cam(self):
            pass
        # WARNING: Decompyle incomplete

        
        def _cam_ready(self):
            if self.mode == self.MODE_IDLE:
                return None
            self._show_vid()
            self.sv.set('Camera live — stay still to begin…')
            self.root.after(35, self._loop)

        
        def _cam_failed(self, msg):
            self._stop(True)
            messagebox.showerror('Camera failed', msg)

        
        def _stop(self, reset = (False,)):
            self.mode = self.MODE_IDLE
            cap = self.cap
            self.cap = None
        # WARNING: Decompyle incomplete

        
        def _loop(self):
            if self.mode == self.MODE_IDLE:
                return None
        # WARNING: Decompyle incomplete

        
        def _tick(self):
            (ok, frame) = self.cap.read()
            if not ok:
                self._read_err = getattr(self, '_read_err', 0) + 1
                if self._read_err > 12:
                    self._stop()
                    messagebox.showerror('Camera lost', 'Camera stopped.\nReconnect and try again.')
                    self._refresh()
                    return None
                self.root.after(50, self._loop)
                return None
            self._read_err = 0
            frame = cv2.flip(frame, 1)
            small = cv2.resize(frame, (640, 360), interpolation = cv2.INTER_LINEAR)
            gray = cv2.equalizeHist(cv2.cvtColor(small, cv2.COLOR_BGR2GRAY))
            self.engine.detect_all(gray) = self, self.frame_n += 1, .frame_n
            small_box = self.engine.detect(gray)
        # WARNING: Decompyle incomplete

        
        def _enrol(self, frame, gray, all_boxes, box, sbox, multi):
            if multi:
                return (self.anim.render(frame, all_boxes, box, 0, 0, [], 'Only ONE person in frame', 'ENROLMENT  —  MULTI-FACE DETECTED', RED, True), False)
            if None.stage == self.ST_MOTION:
                self._upd_steps(1)
                (ml, mp, mm, ms) = self.motion.update(gray, box)
                self.mv_motion.set(f'''{ms:.3f}''')
                self.mv_liveness.set('PASS' if ml else '…')
                self._pset(mp * 25)
                self.mv_step.set('PRESENCE')
                self.mv_conf.set('—')
                self.sv.set(mm)
                frame = self.anim.render(frame, all_boxes, box, 1, 0, self._steps(ml, False, False, False, 1), mm, 'ENROLMENT  —  Step 1: Presence', AMBER, quality = self._quality)
                if ml:
                    self.stage = self.ST_BLINK
                return (frame, False)
        # WARNING: Decompyle incomplete

        
        def _verify(self, frame, gray, all_boxes, box, sbox, multi):
            if multi:
                return (self.anim.render(frame, all_boxes, box, 0, 0, [], 'Remove extra people from frame', 'VERIFICATION  —  REJECTED: MULTIPLE FACES', RED, True), False)
            if None.stage == self.ST_MOTION:
                self._upd_steps(1)
                (ml, mp, mm, ms) = self.motion.update(gray, box)
                self.mv_motion.set(f'''{ms:.3f}''')
                self.mv_liveness.set('PASS' if ml else '…')
                self._pset(mp * 25)
                self.mv_step.set('PRESENCE')
                self.mv_conf.set('—')
                self.sv.set(mm)
                frame = self.anim.render(frame, all_boxes, box, 1, 0, self._steps(ml, False, False, False, 1), mm, 'VERIFICATION  —  Step 1: Presence', AMBER)
                if ml:
                    self.stage = self.ST_BLINK
                return (frame, False)
        # WARNING: Decompyle incomplete

        
        def _open_vault(self):
            self._last_act = time.time()
            os.makedirs(VAULT_DIR, exist_ok = True)
            _unhide(VAULT_DIR)
            subprocess.Popen(f'''explorer "{VAULT_DIR}"''')
            self._refresh()

        
        def _lock(self):
            _hide(VAULT_DIR)
            self.unlocked = False
            _sound_fail()
            _log('LOCKED', f'''drive={self.drive_ltr}:''')
            self.sv.set('Drive locked securely.')
            self._refresh()

        
        def _view_log(self):
            win = tk.Toplevel(self.root)
            win.title('Audit Log')
            win.geometry('720x500')
            win.configure(bg = BG)
            win.transient(self.root)
            tk.Label(win, text = 'Authentication Audit Log', font = ('Segoe UI', 15, 'bold'), fg = FG, bg = BG).pack(pady = (16, 4))
            frm = tk.Frame(win, bg = CARD)
            frm.pack(fill = 'both', expand = True, padx = 16, pady = 10)
            sb = tk.Scrollbar(frm)
            sb.pack(side = 'right', fill = 'y')
            txt = tk.Text(frm, bg = CARD, fg = FG, font = ('Consolas', 10), relief = 'flat', bd = 0, yscrollcommand = sb.set)
            txt.pack(fill = 'both', expand = True, padx = 8, pady = 8)
            sb.config(command = txt.yview)
        # WARNING: Decompyle incomplete

        
        def _wipe_prompt(self):
            if not messagebox.askyesno('⚠  Wipe & Reset', 'This permanently deletes:\n\n  •  Face enrolment\n  •  ALL files in SecureVault\n  •  All config and logs\n\nCannot be undone.', icon = 'warning'):
                return None
            if messagebox.askyesno('Final confirmation', 'ALL DATA LOST FOREVER. Sure?', icon = 'warning'):
                self._do_wipe()
                return None

        
        def _do_wipe(self):
            _log('WIPE', f'''drive={self.drive_ltr}:''', 'WARN')
            self._stop()
            _unhide(VAULT_DIR)
            if os.path.exists(VAULT_DIR):
                
                try:
                    shutil.rmtree(VAULT_DIR)
                    self.engine.wipe()
                    self.state = dict(DEF_STATE)
                    _save_state(self.state)
                    self.unlocked = False
                    self.cam_idx = None
                    messagebox.showinfo('Wipe complete', 'Drive reset. Enrol a new face.')
                    self._refresh()
                    return None
                except:
                    continue


        
        def _quit(self):
            if not self.mode == self.MODE_VERIFY and self.unlocked:
                self.state['attempts'] = self.state.get('attempts', 0) + 1
                _save_state(self.state)
                _log('FAILED', f'''total={self.state['attempts']}''', 'WARN')
                if self.state['attempts'] >= MAX_ATTEMPTS:
                    self._do_wipe()
                    return None
            if self.unlocked and messagebox.askyesno('Lock?', 'Lock vault before closing?'):
                self._lock()
            self._stop()
            self.root.destroy()


    if __name__ == '__main__':
        root = tk.Tk()
        root.withdraw()
        splash = Splash(root)
        for pct, msg in ((10, 'Checking environment…'), (25, 'Loading face engine…'), (45, 'Reading drive state…'), (65, 'Initialising security…'), (85, 'Building interface…'), (100, 'Starting BioLock…')):
            splash.update(pct, msg)
            time.sleep(0.18)
        splash.close()
        root.deiconify()
        BioLock(root)
        root.mainloop()
        return None
    return None
except ImportError:
    _WIN = False
    continue

