# BioLock SSD

Face-recognition based USB drive lock with liveness detection and an
encrypted vault, built as a final-year CSE project at CMR Technical
Campus.

> ⚠️ **Read `docs/DECOMPILATION_NOTES.md` before treating this as
> final.** This source was rebuilt from the compiled `BioLock.exe`
> (the original `.py` wasn't available), and while most of it
> decompiled cleanly, the core camera/verification pipeline had to be
> reconstructed by hand due to Python 3.12 bytecode support gaps in
> current decompilers. Test it against a real camera and compare it to
> what you remember before submitting/relying on it.

## What it does

- Installs itself on a USB drive and enrols **one face** as the only
  key to unlock it.
- 4-step verification on every unlock attempt:
  1. **Presence** — frame-difference liveness check (rejects a static
     photo held up to the camera)
  2. **Blink** — requires natural eye blinks (Haar eye cascade)
  3. **Head turn** — requires a left → right head turn
  4. **Face match** — LBPH face recognition against the enrolled model
- Encrypts a vault marker with a key derived from the enrolled face
  (PBKDF2 + Fernet) — files themselves live in a `SecureVault/` folder
  on the drive, hidden/unhidden as the drive locks/unlocks.
- Auto-locks after a configurable idle period.
- Automatically wipes the vault and face model after too many failed
  attempts.
- Registers itself to run on Windows login (`autorun.inf` +
  `HKCU\...\Run`) so it prompts as soon as the drive is plugged in.
- Keeps a plaintext audit log of enrol/unlock/lock/wipe/failed events.

## Requirements

- Windows (uses `winreg`, `attrib`, Windows drive-type APIs — the app
  will still run on other platforms with those bits silently disabled,
  but it's designed for Windows removable drives)
- Python 3.12
- A webcam

```bash
pip install -r requirements.txt
```

## Running

```bash
python main.py
```

On first run it walks you through face enrolment; on later runs it
requires the 4-step verification above before the `SecureVault` folder
is opened.

## Packaging back into an .exe

The original was built with PyInstaller. Something like:

```bash
pip install pyinstaller
pyinstaller --onefile --windowed --name BioLock main.py
```

You'll likely want to add `--icon` and `--add-data` flags to match
your original build once you've confirmed `main.py` behaves the way
you expect.

## Project structure

```
BioLock/
├── main.py                      # the application
├── requirements.txt
├── docs/
│   └── DECOMPILATION_NOTES.md   # what's recovered vs. reconstructed, and why
└── reference/                   # raw artifacts from the recovery process
    ├── main.pyc                       # extracted PyInstaller bytecode
    ├── main_pycdc_raw_output.py       # raw (partial/broken) decompiler output
    └── main_bytecode_disassembly.txt  # full opcode-level disassembly
```

## Team

CMR Technical Campus · CSE-E · R-22
Rishi · Karthik · Tejasree
