# How this source was rebuilt

`BioLock.exe` was a PyInstaller-frozen build (Python 3.12) and the
original `.py` source wasn't available, so `main.py` in this repo was
rebuilt from the compiled app itself:

1. `pyinstxtractor-ng` extracted the PyInstaller archive from the `.exe`,
   recovering the compiled `main.pyc` bytecode (this is `reference/main.pyc`).
2. [`pycdc`](https://github.com/zrax/pycdc) (built from source, since it's
   one of the few decompilers with any Python 3.12 opcode support) was
   run against that bytecode. Its raw output is `reference/main_pycdc_raw_output.py`.
3. `pycdas` produced a full bytecode disassembly for cross-reference:
   `reference/main_bytecode_disassembly.txt`.

## Why `main.py` isn't a byte-for-byte recovery

Python 3.12's bytecode (the adaptive/specializing interpreter, opcodes
like `CALL_INTRINSIC_1`, `LOAD_FAST_CHECK`, `POP_JUMP_IF_NOT_NONE`, the
newer exception-table format, etc.) isn't fully handled by public
decompilers yet. `pycdc`'s raw output recovered roughly 55-60% of the
app cleanly — all imports, constants, the theme/colour palette, simple
I/O helpers, state/config persistence, and the wipe logic came back
correct. The rest — notably the live camera loop, the animated overlay
renderer, the Tkinter layout, and the camera-picker dialog — came back
empty (`WARNING: Decompyle incomplete`) or corrupted.

Those pieces were **rewritten by hand** in `main.py`, based on:
- the function signatures pycdc *did* recover,
- how each function's return value is consumed elsewhere in the file,
- the constants involved (e.g. `MIN_CONF`, `BLINKS_NEEDED`, `HEAD_TURN_PCT`,
  `MOTION_THRESH`, `ENROL_FRAMES`),
- standard implementations of the same technique (Haar-cascade face
  detection, LBPH recognition, eye-cascade blink detection, frame-diff
  liveness, head-turn tracking via bounding-box centre).

This got the app to a syntactically valid, importable, smoke-tested
state (see below) — but it is a **reconstruction**, not a recovery, for
those specific functions. If your original logic differed in the
details (e.g. exact confidence-score formula, exact particle-burst
trigger points, exact head-turn thresholding), you'll want to diff your
memory of the original against these and adjust:

| Area | Status |
|---|---|
| Imports, constants, theme colours, paths | Recovered cleanly |
| `_hide/_unhide/_log/_beep/*sound*` | Recovered cleanly |
| Drive helpers, drive-id, autorun | Recovered, minor cleanup |
| State/config load & save | Recovered, minor cleanup |
| Vault key derivation (Fernet/PBKDF2) | Recovered cleanly |
| Cascade lookup, lighting quality | Recovered cleanly |
| `BlinkDetector` / `HeadTurn` / `MotionLive` | **Reconstructed** |
| `FaceEngine` (`_load`, `predict`, part of `train`) | **Reconstructed** |
| `ParticleSystem` / `Anim.render` | **Reconstructed** |
| `_scan_cams` / `CamPicker` | **Reconstructed** |
| `BioLock.__init__` / `_build_ui` | **Reconstructed** |
| Camera loop (`_tick`, `_loop`, `_start`, `_open_cam`, `_enrol`, `_verify`) | **Reconstructed** |
| `Splash`, `show_about` | Recovered cleanly |

## What's been verified so far

- `main.py` compiles (`python -m py_compile`) and every class/function
  imports without `NameError`s.
- Core logic classes (`FaceEngine`, `BlinkDetector`, `HeadTurn`,
  `MotionLive`, `Anim`) were instantiated and smoke-tested against
  synthetic (random) image data — `FaceEngine.train()` /
  `.predict()` round-tripped, `Anim.render()` produced a valid frame,
  etc.
- **Not yet verified**: an actual live webcam run end-to-end (this
  container has no camera/display), so please run it yourself and
  compare each screen against what you remember before treating it as
  final for submission.

## If you want to double-check a specific function

Open `reference/main_bytecode_disassembly.txt` and search for the
function name — you'll get the exact Python 3.12 bytecode for it,
which you can read instruction-by-instruction if you want to confirm
or correct a specific piece of logic in `main.py`.
